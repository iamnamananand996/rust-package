mod lib;

fn main() {
    lib::add_one(5);
}
